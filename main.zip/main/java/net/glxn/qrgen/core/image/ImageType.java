package net.glxn.qrgen.core.image;

public enum ImageType {
    JPG, GIF, PNG, BMP
}
