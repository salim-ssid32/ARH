package com.androidremote.hacker.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ToggleButton;

import com.androidremote.hacker.R;
import com.androidremote.hacker.tools.Commandes;
import com.androidremote.hacker.tools.CreateConnection;
import com.androidremote.hacker.tools.InfoConnection;
import com.androidremote.hacker.tools.Remote;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class Panel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel);

        Remote.panel_act=this;
        Remote.panel_context=this;

        SwitchMaterial lpdr = (SwitchMaterial) findViewById(R.id.panel_lpdr);
        SwitchMaterial lpdv = (SwitchMaterial) findViewById(R.id.panel_lpdv);
        Button apl0 = (Button) findViewById(R.id.panel_apl0);
        Button apl1 = (Button) findViewById(R.id.panel_apl1);
        MaterialButton vbr = (MaterialButton) findViewById(R.id.panel_vbr);
        MaterialButton ph = (MaterialButton) findViewById(R.id.panel_ph);
        ToggleButton vu = (ToggleButton) findViewById(R.id.panel_picvu);


        lpdr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lpdr.isChecked()){
                    CreateConnection.sendCommand("LPDR1");
                } else{
                    CreateConnection.sendCommand("LPDR0");
                }
            }
        });

        lpdv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lpdv.isChecked()){
                    CreateConnection.sendCommand("LPDV1");
                } else{
                    CreateConnection.sendCommand("LPDV0");
                }
            }
        });
        apl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateConnection.sendCommand("APL1");
            }
        });

        apl0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateConnection.sendCommand("APL0");
            }
        });

        vbr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateConnection.sendCommand("VIBR");
            }
        });

        ph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Commandes.ImageProcess(vu);
            }
        });


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Commandes.destroy(this,this);
    }
}