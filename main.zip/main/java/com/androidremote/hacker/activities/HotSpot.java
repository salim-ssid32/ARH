package com.androidremote.hacker.activities;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;


import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;


import com.androidremote.hacker.R;
import com.androidremote.hacker.tools.Commandes;
import com.androidremote.hacker.tools.InfoConnection;
import com.google.android.material.button.MaterialButton;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


public class HotSpot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hot_spot);
        Commandes.checkPermissions(this,this);
        ((MaterialButton) findViewById(R.id.hacker_btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new IntentIntegrator(HotSpot.this).setBeepEnabled(true)
                        .setPrompt("Scanning victim")
                        .setOrientationLocked(false)
                        .initiateScan();
            }
        });
        //Commandes.hacker(this, this, "k");
        ((MaterialButton) findViewById(R.id.victim_btn)).setOnClickListener(v -> Commandes.victime(this, this, findViewById(R.id.victim_adresse)));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
//        Log.e("OKLM",nee
        switch (requestCode) {
            case 1: {
                if (!(grantResults.length > 0
                        && grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
                    Commandes.checkPermissions(this, this);
                }
            }
        }
    }




    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        IntentResult r =IntentIntegrator.parseActivityResult(requestCode,resultCode,intent);

        if (r != null) {
            String contents = r.getContents();
            if (contents != null ) {
                runOnUiThread(() ->
                        Commandes.hacker(this, this, contents)
                );
            }
        }
    }

}