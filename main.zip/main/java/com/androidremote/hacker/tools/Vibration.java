package com.androidremote.hacker.tools;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;


public final class Vibration {
    private static Vibrator vib;



    public static void start(int time, Activity act){
        vib = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
//        vib.vibrate(time*1000);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //deprecated in API 26
                vib.vibrate(1000);
            }
        }catch (Exception e){
            e.printStackTrace();
            Log.e("VIBRATION","Error to vibrate");
        }

    }
}
