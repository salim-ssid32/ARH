package com.androidremote.hacker.tools;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

public class Lampe {

    public static void startdevant(Activity act, int on) throws CameraAccessException {
        CameraManager camManager;
        Camera mCamera;
        Camera.Parameters parameters;
        if(on == 1){// TORCH ON
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    camManager = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
                    String cameraId = null;
                    if (camManager != null) {
                        cameraId = camManager.getCameraIdList()[1];
                        camManager.setTorchMode(cameraId, true);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("TORCH FRONT", "Error in operation");
                }
            } else {
                mCamera = Camera.open(1);
                parameters = mCamera.getParameters();
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                mCamera.setParameters(parameters);
                mCamera.startPreview();
            }
        }else { // TORCH OFF
            Log.e("TORCH FRONT", "API <= 26");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    String cameraId;
                    camManager = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
                    if (camManager != null) {
                        cameraId = camManager.getCameraIdList()[1]; // Usually front camera is at 0 position.
                        camManager.setTorchMode(cameraId, false);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("TORCH FRONT", "Error in operation");
                }
            } else {
                mCamera = Camera.open(1);
                parameters = mCamera.getParameters();
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                mCamera.setParameters(parameters);
                mCamera.stopPreview();
            }
        }
    }




    public static void startderriere(Activity act, int on) throws CameraAccessException {
        CameraManager camManager;
        Camera mCamera;
        Camera.Parameters parameters;
        if (on == 1) {// TORCH ON
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    camManager = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
                    String cameraId = null;
                    if (camManager != null) {
                        cameraId = camManager.getCameraIdList()[0];
                        camManager.setTorchMode(cameraId, true);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("TORCH FRONT", "Error in operation");
                }
            } else {
                mCamera = Camera.open();
                parameters = mCamera.getParameters();
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                mCamera.setParameters(parameters);
                mCamera.startPreview();
            }
        } else { // TORCH OFF
            Log.e("TORCH FRONT", "API <= 26");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    String cameraId;
                    camManager = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
                    if (camManager != null) {
                        cameraId = camManager.getCameraIdList()[0];
                        camManager.setTorchMode(cameraId, false);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("TORCH FRONT", "Error in operation");
                }
            } else {
                mCamera = Camera.open();
                parameters = mCamera.getParameters();
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                mCamera.setParameters(parameters);
                mCamera.stopPreview();
            }
        }
    }
}
