package com.androidremote.hacker.tools;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

//17890
public class InfoConnection {
    public static String ip=null;
    public static boolean isConnected=false;
    public static boolean aError=false;
    public static String ip(Activity act){

        String _ip;
        WifiManager wifi = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if(isWifi(act)) {
           _ip = ip2str(wifi.getConnectionInfo().getIpAddress());
            ip = _ip.equals("0.0.0.0") ? null : _ip;
            return _ip.equals("0.0.0.0") ? null : _ip;
        }
        if(isAp(act)){
            //return ip2str(wifi.getDhcpInfo().serverAddress);
            _ip= getLocalIpAddress();
            ip = _ip;
            return _ip;
        }

            return null;
    }


    public static String ip2str(int i){
        return Formatter.formatIpAddress(i);
    }


    public static boolean isWifi(Activity act){
        WifiManager wifi = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        return wifi.isWifiEnabled();
    }
    public static boolean isAp(Activity act){
        WifiManager wifi = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            Method method = wifi.getClass().getDeclaredMethod("isWifiApEnabled");
            method.setAccessible(true);
            return (Boolean) method.invoke(wifi);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return  false;
    }


    public static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
