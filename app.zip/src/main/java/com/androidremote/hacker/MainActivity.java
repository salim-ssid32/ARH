package com.androidremote.hacker;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.webkit.WebView;
import android.widget.Toast;

import com.androidremote.hacker.activities.HotSpot;
import com.androidremote.hacker.tools.Commandes;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Commandes.checkPermissions(this,this);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer,toolbar,R.string.app_name,R.string.app_name);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener) this);




        ///////////////////////////////////////


    }

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem i) {
        // Inflate the menu; this adds items to the action bar if it is present.
        if (i.getItemId() == R.id.action_settings) {
            Toast.makeText(this, "Settings", Toast.LENGTH_LONG).show();
        }
        if (i.getItemId() == R.id.action_connect) {
            Commandes.startActivity(this,HotSpot.class);
        }
        return true;
    }*/



//    public void onclickOutils(MenuItem item) {
//
//        //finish();
//    }

//    public void onDroidFile(MenuItem item) {
//        Intent i = new Intent(MainActivity.this, HotSpot.class);
//        startActivity(i);
//    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        switch (id){
            case R.id.nav_send_mail :
                Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                String[] recipients = new String[]{"koravant1@gmail.com", "",};
                emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, recipients);
                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Write for Android Remote Hacker");
//                emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "This is email's message");
                emailIntent.setType("message/rfc822");
                startActivity(Intent.createChooser(emailIntent, "Send mail..."));
//                Commandes.showToast(this,this,"home");
                break;
            case R.id.nav_outils:
//                Commandes.showToast(this,this,"home");
                Commandes.startActivity(this,Outils.class);
                break;
            case R.id.nav_hacker:
                Commandes.startActivity(this,HotSpot.class);
//                Commandes.showToast(this,this,"home");
                break;
            case R.id.nav_share:
                Intent i = new Intent(android.content.Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT,"Send Link");
                i.putExtra(Intent.EXTRA_TEXT,"https://play.google.com/store/apps/details?id=com." +
                        "androidremote.hacker");
                startActivity(Intent.createChooser(i, "Share via"));
//                Commandes.startActivity(this,HotSpot.class);
//                Commandes.showToast(this,this,"home");
                break;
            case R.id.nav_about:
//                Commandes.startActivity(this,HotSpot.class);
//                Commandes.showToast(this,this,"home");
                Commandes.alerte(this,this,"About",getResources().getString(R.string.app_description));
                break;
            default:
                break;
        }
//66429509
//        https://openclassrooms.com/fr/courses/4568596-construisez-une-interface-utili
//        sateur-flexible-et-adaptative/4798046-ameliorez-votre-navigation-drawer
        this.drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    @Override
    public void onBackPressed() {
        if (this.drawer.isDrawerOpen(GravityCompat.START)) {
            this.drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}