package com.androidremote.hacker.tools;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.provider.Settings;

public class MyService extends Service {
    MediaPlayer music;
    public MyService() {
    }

    @Override
    public void onCreate(){
        music= MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
        super.onCreate();
        music.setLooping(true);
    }

    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent i, int f, int s){
        music.start();
        return 1;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if(music!=null && music.isPlaying()){
            music.stop();
            music.reset();
            music.release();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}