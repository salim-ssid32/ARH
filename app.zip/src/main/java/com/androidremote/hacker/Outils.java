package com.androidremote.hacker;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.androidremote.hacker.picture.CameraPreview;
import com.androidremote.hacker.picture.OnPictureCapturedListener;
import com.androidremote.hacker.picture.PictureService;
import com.androidremote.hacker.picture.ShowPicture;
import com.androidremote.hacker.tools.Lampe;
import com.androidremote.hacker.tools.Sonnerie;
import com.androidremote.hacker.tools.Vibration;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;


import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;


public class Outils extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outils);
        checkPermissions();

        Button btn = (Button) findViewById(R.id.btn_call);
        Button btn_photo = (Button) findViewById(R.id.btn_photo);
        Button btn_vibrer = (Button) findViewById(R.id.btn_vibrer);
        Button btn_son_appel=(Button) findViewById(R.id.son_appel);
        Button b_stop_son_appel=(Button) findViewById(R.id.son_appel_stop);
        SwitchMaterial btn_lampe_back= findViewById(R.id.lampe_back);
        SwitchMaterial btn_lampe_front= findViewById(R.id.lampe_front);


        //#################################### LAMPE DERRIERE

        btn_lampe_back.setOnClickListener(v -> {
            try {
                Lampe.startderriere(this, btn_lampe_back.isChecked()? 1:0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        //#################################### LAMPE DEVANT

        btn_lampe_front.setOnClickListener(v -> {
            try {
                Lampe.startdevant(this, btn_lampe_front.isChecked()? 1:0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });



        //############################# SONNERIE APPEL START

        btn_son_appel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Outils.this, Sonnerie.class);
                startService(intent);
            }
        });

        //############################# SONNERIE APPEL STOP

        b_stop_son_appel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Outils.this, Sonnerie.class);
                stopService(intent);
            }
        });

        //##################### APPEL
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comcall();
            }
        });

        //####################### PHOTO
        btn_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //prendrePhoto();
                Intent i =new Intent(Outils.this, ShowPicture.class);
                startActivity(i);
            }
        });

        //######################## VIBRATION
        btn_vibrer.setOnClickListener(v -> Vibration.start(1,this));


    }




    public void comcall(){
            AppCompatEditText s = (AppCompatEditText) findViewById(R.id.num_appel);
        if(s.getText().length()==0){
            s.setError("Entrer le numero");
        }
            String num=s.getText().toString();
            Intent i =new Intent(Intent.ACTION_CALL);
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},1);
            }
            else {
                i.setData(Uri.parse("tel:"+num));
                startActivity(i);
            }

    }






    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if (!(grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    checkPermissions();
                }
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    private void checkPermissions() {
        final String[] requiredPermissions = {
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA,Manifest.permission.CALL_PHONE,
        };
        final List<String> neededPermissions = new ArrayList<>();
        for (final String p : requiredPermissions) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(),
                    p) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(p);
            }
        }
        if (!neededPermissions.isEmpty()) {
            requestPermissions(neededPermissions.toArray(new String[]{}),
                    1);
        }
    }







}
